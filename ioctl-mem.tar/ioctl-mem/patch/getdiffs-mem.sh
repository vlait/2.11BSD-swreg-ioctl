diff -c /mnt/src/sys/pdp/mem.c /usr/src/sys/pdp/mem.c
diff -c /mnt/src/sys/pdp/conf.c /usr/src/sys/pdp/conf.c
diff -c /mnt/src/sys/h/ioctl.h /usr/src/sys/h/ioctl.h
