diff -c /mnt/src/sys/sys/kern_sysctl.c /usr/src/sys/sys/kern_sysctl.c
diff -c /mnt/src/sys/h/sysctl.h /usr/src/sys/h/sysctl.h
diff -c /mnt/src/bin/sysctl/sysctl.c /usr/src/bin/sysctl/sysctl.c
diff -c /mnt/src/bin/sysctl/sysctl.8 /usr/src/bin/sysctl/sysctl.8
