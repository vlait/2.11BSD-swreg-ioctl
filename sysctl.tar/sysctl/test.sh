echo reading SW
sysctl hw.csw
echo writing 7 to DR, turn dial to DR...
sysctl -w hw.csw=7

