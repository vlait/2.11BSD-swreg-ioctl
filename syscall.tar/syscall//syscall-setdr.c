#include<stdio.h>

extern unsigned int setdr(unsigned int );

int main(argc, *argv[])
{
	unsigned int val;

	if(argc != 2) {
		printf("usage: %s <integer value>\n",argv[0]);
		exit(1);
	}
	val = atoi(argv[1]);
	
	setdr(val);	
	
}

