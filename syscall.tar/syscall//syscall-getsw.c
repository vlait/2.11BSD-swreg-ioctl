#include<stdio.h>

extern unsigned int getsw();

void main()
{
printf("%u\n",getsw());
}

