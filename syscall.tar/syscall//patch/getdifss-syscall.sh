diff -c /mnt/src/sys/sys/init_sysent.c /usr/src/sys/sys/init_sysent.c
diff -c /mnt/src/sys/pdp/kern_pdp.c /usr/src/sys/pdp/kern_pdp.c
diff -c /mnt/include/syscall.h /usr/include/syscall.h
diff -c /mnt/src/lib/libc/pdp/sys/Makefile /usr/src/lib/libc/pdp/sys/Makefile
