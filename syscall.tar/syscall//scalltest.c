#include<stdio.h>

extern unsigned int getsw();

void main()
{
int a=1;
printf("%u read\n",getsw());
setdr(a);
}

